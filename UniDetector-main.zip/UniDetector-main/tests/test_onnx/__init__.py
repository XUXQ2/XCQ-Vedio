# Copyright (c) OpenMMLab. All rights reserved.
from .utils import ort_validate

__all__ = ['ort_validate']
